# PoisonDragons-Fabric-1.21.10-rewrite

Nezávislá nová implementace pro **Minecraft 1.21.10 + Fabric**. Nejde o přímou konverzi původního Forge bajtkódu a nepoužívá původní chráněné textury ani modely.

## Požadavky
- Java 21
- Minecraft 1.21.10
- Fabric Loader 0.18.2 nebo novější
- Fabric API 0.137.0+1.21.10
- Ice and Fire Fabric 2.1.13-beta.14.3+1.21.10
- Rampart 1.1.0+1.21.10

## Funkce v této implementaci
- vlastní dračí entita s variantami: sunstone, obsidian, jade, amethyst
- vlastní nové modely a textury (jedna společná geometrie s unikátními texturami)
- vejce lze položit; inkubují se při random ticku a vylíhnou mládě
- mládě přirozeně roste podle systému Minecraftu
- ochočení pomocí sladkých bobulí; po ochočení následuje majitele
- plíživé kliknutí majitele prázdnou rukou přepíná sezení
- vzdálený ochočený drak se umí vznést a přiletět zpět k majiteli
- blízký ochočený drak poskytuje majiteli krátkou pasivní odolnost
- vzácná dračí hnízda s vejcem se generují v overworldu
- původní dekorativní položky z přehledu byly nahrazeny novými, samostatně vytvořenými texturami

## Omezení
- Ice and Fire a Rampart jsou povinné závislosti, ale tato verze zatím nepřipojuje vlastní draky do interní registrace nativních draků Ice and Fire; jde o samostatné dračí společníky vedle nich
- nepřenáší se původní Forge internals, staré mixiny ani původní assety
- nepřidává toxické / jedovaté efekty ani útočné mechaniky
- model a animace jsou nové a jednodušší než případné původní animační rigy
- létání je automatické dohnání majitele, nikoliv plnohodnotné ovládání letu nebo létání na drakovi
- nest generation je jednoduchý worldgen feature: hnízdo + náhodné vejce
- kód zatím nebyl zkompilován ani otestován v Minecraftu v tomto prostředí

## Sestavení
V prostředí s Gradle 8.14+ a Java 21 spusť v adresáři projektu:

```bash
gradle build
```

Výsledný JAR bude v `build/libs/`. Oba projekty instaluj samostatně společně s výše uvedeným Ice and Fire a Rampart.

## Změny v této revizi (nekompilováno, viz BUILD_REPORT.md)
- Přidána konfigurace `config/poisondragons_fabric.properties` (vytvoří se při prvním startu): `hatchAdvanceChancePercent` (rychlost líhnutí), `nestEnabled`, `guardianEnabled`, `guardianRadius`, `recallDistance`, `teleportDistance`.
- Líhnutí: vejce má 3 stupně; každý náhodný tik bloku (výchozí `randomTickSpeed` 3) posune stupeň s pravděpodobností `hatchAdvanceChancePercent` %. Při 100 % vychází zhruba 3–4 minuty reálného času na vylíhnutí. Pod vejcem musí být volný vzduch nad blokem.
- Vzácnost hnízd: `data/poisondragons_fabric/worldgen/placed_feature/dragon_nest.json` (`rarity_filter.chance`, výchozí 64 = přibližně 1 pokus na 64 chunků).
- Opraven logický konflikt: vanilla FollowOwner teleportoval už na 12 blocích, takže přilétnutí (od 14) se nikdy neuplatnilo. Teleport je nyní až od `teleportDistance` (48).
- Přidány tagy `minecraft:mineable/*` (rudy/bloky těžitelné správným nástrojem).
- `fabric.mod.json`: odstraněna přímá závislost na `rampart` (je závislostí Ice and Fire, addon ji sám nepoužívá). Závislost `iceandfire` zůstává.

## Sestavení
Viz `build.sh` / `build.bat` v kořeni kombinovaného ZIPu nebo přímo `gradle build` (Gradle 8.14+, Java 21).
