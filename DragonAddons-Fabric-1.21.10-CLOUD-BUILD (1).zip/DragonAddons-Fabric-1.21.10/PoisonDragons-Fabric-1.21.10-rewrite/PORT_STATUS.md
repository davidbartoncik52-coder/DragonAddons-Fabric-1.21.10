STATUS: SOURCE REVISED; STILL NOT COMPILED WITH GRADLE AND NOT TESTED IN-GAME.

Verified (static, in a sandbox without internet): JSON validity, asset cross-references, fabric.mod.json against the
supplied Ice and Fire / Rampart jars, parser-level Java syntax, DragonConfig compiled and run against a FabricLoader stub.
Not verified: compilation against Minecraft 1.21.10 / Fabric API 0.137.0+1.21.10, runtime loading, any gameplay.
See ../BUILD_REPORT.md for details and known risks.
