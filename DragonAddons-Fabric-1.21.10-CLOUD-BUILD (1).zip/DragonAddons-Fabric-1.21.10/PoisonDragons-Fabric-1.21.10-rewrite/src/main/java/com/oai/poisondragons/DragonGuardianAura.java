package com.oai.poisondragons;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.phys.AABB;

public final class DragonGuardianAura {
    private DragonGuardianAura() {}
    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (!DragonConfig.guardianEnabled || world.getGameTime() % 40L != 0L) return;
            for (ServerPlayer player : world.players()) {
                boolean nearby = !world.getEntitiesOfClass(CompanionDragonEntity.class,
                    player.getBoundingBox().inflate(DragonConfig.guardianRadius), dragon -> dragon.isOwnedBy(player)).isEmpty();
                if (nearby) player.addEffect(new MobEffectInstance(
                    MobEffects.DAMAGE_RESISTANCE, 60, 0, true, false, true));
            }
        });
    }
}
