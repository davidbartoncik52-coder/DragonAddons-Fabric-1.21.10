package com.oai.poisondragons.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import com.oai.poisondragons.CompanionDragonEntity;
import com.oai.poisondragons.DragonContent;
import com.oai.poisondragons.PoisonDragonsFabric;

public final class DragonEntityRenderer extends MobRenderer<CompanionDragonEntity, DragonRenderState, DragonModel> {
    public DragonEntityRenderer(EntityRendererProvider.Context context) {
        super(context, new DragonModel(context.bakeLayer(DragonAddonClient.DRAGON_LAYER)), 0.65F);
    }

    @Override
    public DragonRenderState createRenderState() {
        return new DragonRenderState();
    }

    @Override
    public void extractRenderState(CompanionDragonEntity entity, DragonRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.variant = entity.getVariant();
    }

    @Override
    public ResourceLocation getTextureLocation(DragonRenderState state) {
        int index = Math.max(0, Math.min(DragonContent.SPECIES.length - 1, state.variant));
        return ResourceLocation.fromNamespaceAndPath(PoisonDragonsFabric.MOD_ID,
            "textures/entity/" + DragonContent.SPECIES[index] + ".png");
    }
}
