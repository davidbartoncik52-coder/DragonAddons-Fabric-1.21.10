package com.oai.poisondragons;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

public final class DragonNestFeature extends Feature<NoneFeatureConfiguration> {
    public DragonNestFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos nestPos = context.origin();
        if (DragonContent.EGGS.isEmpty()) return false;
        if (!level.getBlockState(nestPos.below()).isSolid()) return false;
        if (!level.getBlockState(nestPos).canBeReplaced()) return false;
        level.setBlock(nestPos, DragonContent.NEST.defaultBlockState(), 2);
        int variant = context.random().nextInt(DragonContent.EGGS.size());
        Block egg = DragonContent.EGGS.get(variant);
        BlockPos eggPos = nestPos.above();
        if (level.getBlockState(eggPos).canBeReplaced()) {
            BlockState eggState = egg.defaultBlockState();
            level.setBlock(eggPos, eggState, 2);
        }
        return true;
    }
}
