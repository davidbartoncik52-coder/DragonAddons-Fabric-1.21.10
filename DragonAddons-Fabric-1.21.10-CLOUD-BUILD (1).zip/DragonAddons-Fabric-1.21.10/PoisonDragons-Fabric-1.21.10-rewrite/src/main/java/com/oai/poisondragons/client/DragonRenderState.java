package com.oai.poisondragons.client;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
public final class DragonRenderState extends LivingEntityRenderState {
    public int variant;
}
