package com.oai.poisondragons;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

public final class DragonWorldgen {
    private DragonWorldgen() {}
    public static final ResourceKey<PlacedFeature> NEST_PLACED = ResourceKey.create(
        Registries.PLACED_FEATURE,
        ResourceLocation.fromNamespaceAndPath("poisondragons_fabric", "dragon_nest")
    );
}
