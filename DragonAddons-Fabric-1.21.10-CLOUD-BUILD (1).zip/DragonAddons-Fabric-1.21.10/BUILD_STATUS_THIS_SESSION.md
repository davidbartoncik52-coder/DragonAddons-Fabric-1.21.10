# Stav této kontroly

- Nahraný `files.zip` byl rozbalen a jeho obsah prohlédnut.
- `BUILD_REPORT.md` potvrzuje, že původní autor zdrojových projektů JARy nesestavil.
- V tomto prostředí je dostupná Java 21.
- Příkaz `gradle` není dostupný.
- Přístup na `https://maven.fabricmc.net/` selhal na DNS (`Could not resolve host`).
- Proto v této relaci nebyla provedena kompilace proti Minecraft 1.21.10 / Fabric API ani herní test.
- Přidán GitHub Actions workflow pro sestavení obou JARů v prostředí s internetovým přístupem.
