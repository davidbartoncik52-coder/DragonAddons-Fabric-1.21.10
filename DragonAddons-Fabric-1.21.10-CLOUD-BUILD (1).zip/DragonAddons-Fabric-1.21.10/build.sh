#!/usr/bin/env bash
# Builds both mods independently and collects the JARs in build-output/. Needs Java 21 and Gradle 8.14+ and internet.
set -euo pipefail
cd "$(dirname "$0")"
command -v gradle >/dev/null || { echo "Gradle 8.14+ not found in PATH"; exit 1; }
java -version 2>&1 | grep -q 'version "21' || echo "WARNING: Java 21 expected (found: $(java -version 2>&1 | head -1))"
mkdir -p build-output
build() {  # <project dir> <output name>
  ( cd "$1" && gradle build --no-daemon )
  jar=$(ls "$1"/build/libs/*.jar | grep -v -- '-sources' | head -1)
  cp "$jar" "build-output/$2" && echo "OK: build-output/$2"
}
build PoisonDragons-Fabric-1.21.10-rewrite PoisonDragons-Fabric-1.21.10.jar
build SannansDragons-Fabric-1.21.10-rewrite SannansDragons-Fabric-1.21.10.jar
