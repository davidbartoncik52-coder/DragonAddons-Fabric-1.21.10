# Jak sestavit oba mody v cloudu (Minecraft 1.21.10 + Fabric)

Tento balíček obsahuje dva samostatné zdrojové projekty a workflow pro GitHub Actions.
Workflow sestaví oba projekty na čistém runneru s Java 21 a Gradle 8.14.3 a uloží výsledné JARy jako jeden artefakt.

## Co je v balíčku

- `PoisonDragons-Fabric-1.21.10-rewrite/`
- `SannansDragons-Fabric-1.21.10-rewrite/`
- `build.sh` a `build.bat` pro místní sestavení
- `.github/workflows/build.yml` pro automatické cloudové sestavení
- `BUILD_REPORT.md` s výsledky statické kontroly a dosud neověřenými částmi

## Cloudové sestavení

1. Rozbal tento ZIP.
2. Nahraj obsah složky `DragonAddons-Fabric-1.21.10` do nového GitHub repozitáře (ne pouze ZIP jako jeden soubor).
3. Otevři kartu **Actions**. Workflow `Build Dragon Addons (Fabric 1.21.10)` se spustí po nahrání zdrojů; případně ho spusť přes **Run workflow**.
4. Po úspěšném dokončení otevři konkrétní běh workflow a v sekci **Artifacts** stáhni `DragonAddons-Fabric-1.21.10-JARs`.
5. Uvnitř staženého artefaktu budou dva samostatné JAR soubory.

## Místní sestavení ve Windows

Po instalaci Java 21 a Gradle 8.14.3 nebo novější otevři PowerShell/CMD v kořenové složce projektu a spusť:

```bat
build.bat
```

Výsledné soubory budou ve složce `build-output`.

## Závislosti hry

Pro spuštění potřebuješ Minecraft 1.21.10, Fabric Loader 0.18.2+, Fabric API 0.137.0+1.21.10, Ice and Fire Fabric 2.1.13-beta.14.3+1.21.10 a Rampart 1.1.0+1.21.10.

## Důležité omezení

Tento balíček ještě neobsahuje zkompilované JARy. V tomto pracovním prostředí nebylo možné spustit Gradle build: Gradle není nainstalovaný a přístup k Maven/Fabric repozitáři selhal při DNS překladu. Workflow je připravené, ale dokud GitHub Actions úspěšně nespustí oba buildy, nesmí se výsledné mody považovat za zkompilované ani otestované.

Viz také `BUILD_REPORT.md` a `PORT_STATUS.md` v každém projektu.
